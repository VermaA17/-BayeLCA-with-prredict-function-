fx.g.intern <-
function(y, theta1) prod(dbinom(y, 1, theta1))
