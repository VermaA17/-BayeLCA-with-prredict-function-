predict.bl<-function(object,Ham_test=NULL,train=NULL,....){
  #tic("Imputation time")  
  if(is.null(Ham_test)){
    if(is.null(train)){
      stop("Parameters not supplied.")
    }else{Zscore(train,object)}
  }else{
    miss<- any(is.na(Ham_test))
    if(miss)
    {
      if(is.null(train)){print("remvoing samples having null values")
        new1<-na.omit(Ham_test)}else{
          Ham_tes1<-na.omit(Ham_test)
          test<-Ham_test[!complete.cases(Ham_test),]
          #toc()
          #unseen<-unseen[,-unlist(drop_col),drop=FALSE]
          #na.test<-apply(test,1,anyNA)
          #w<-which(na.test==TRUE)
          #test.reduce<-test[w,]
          #idx<-apply(test.reduce,1,function(x) which(is.na(x)==TRUE))
          for(row in 1:nrow(test)){ 
            unseen<-test[row,]
            drop_col<-match(colnames(unseen)[apply(unseen, 2, anyNA)],names(unseen)) #column indexs having NAs
            unseen<-unseen[,-unlist(drop_col),drop=FALSE]
            seen<-train[,-unlist(drop_col),drop=FALSE]
            seen<-seen[!duplicated(seen),]
            
            hf<- data.frame(matrix(unlist(apply(seen,1,'-',unseen)), nrow=nrow(seen), byrow=T))#Substraction 
            hd<-abs(hf)  
            abc<-rowSums(hd) #sum of difference of elements 
            
            min_index<-which(abc==min(abc))
            min_distance<-train[c(unlist(min_index)),]
            akio<-(table(sapply(min_distance, paste, collapse="")))
            closest<-min_distance[ which.max(rank(akio,ties.method = "random")),]
            test[row,unlist(drop_col)]<-closest[unlist(drop_col)]
          }
          new1<-rbind(test,Ham_tes1)
        }
    }else{
      new1<-Ham_test  
    }
    var.prob1 <- as.matrix(object$itemprob )
    var.prob0 <- as.matrix (1-object$itemprob)
    group<- object$classprob
    new2<-new1
     for (row in 1:nrow(new1)){
      class_prob=c()
      for (x in 1:length(group)){
        one<-new1[row,]*var.prob1[x,]
        zero<-abs(new1[row,]-1)*var.prob0[x,]
        three<-one+zero
        i_prob<-(prod(three))*group[x]
        class_prob[x]<-i_prob
      }
      new2$Classes[row]<-cbind.data.frame(round((class_prob/(sum(class_prob))),3))
      check1<-apply(subset(new2, select = -c(Classes)), 1, paste,collapse='')
      check3<-as.list((check1))
      check5<-matrix(unlist(new2$Classes),ncol=length(group),nrow = nrow(new2),byrow=TRUE)
      check6<-matrix(cbind(check3,check5),ncol=(length(group)+1),nrow=nrow(new2),byrow=FALSE)
    } 
    check6
  }
}
